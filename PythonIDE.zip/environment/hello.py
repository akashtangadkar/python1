print("Hello world")

a=45
b=35
c=a+b
print(c)
print(type(c))

# g=int(input("num1="));
# h=int(input("num2="))
# k=g+h
# print(k)
print("Python has three numeric types: int, float, and complex")
myValue=1
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myValue=3.14
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))


myValue=5j


